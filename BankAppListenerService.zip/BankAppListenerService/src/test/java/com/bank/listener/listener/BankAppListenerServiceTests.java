package com.bank.listener.listener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.bankapplistenerservice.BankAppListenerService;

@SpringBootTest(classes = BankAppListenerService.class)
class BankAppListenerServiceTests {

	@Test
	void contextLoads() {
	}

}
