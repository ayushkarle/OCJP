package com.bankappservice.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

//sj196ofr8ctb7bjc4ev

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bankappservice.Entity.Employee;
import com.bankappservice.Entity.EmployeeDTO;
import com.bankappservice.Service.EmployeeService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/employees")
public class EmployeeController {

    private static final Logger logger = LogManager.getLogger(EmployeeController.class);

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable Long id) {
        logger.info("GET /employees/{} - Fetching employee by ID", id);
        return employeeService.getEmployeeById(id);
    }

    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
    logger.info("POST /employees - Creating new employee: {}",
    employee.getName());
    return employeeService.createEmployee(employee);
    }



// @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
// public ResponseEntity<?> uploadEmployeeWithDocument(
//         @RequestPart("employee") String employeeJson,
//         @RequestPart(value = "document", required = false) MultipartFile document) {
//     try {
//         // Convert JSON string to EmployeeDTO
//         ObjectMapper objectMapper = new ObjectMapper();
//         EmployeeDTO employeeDTO = objectMapper.readValue(employeeJson, EmployeeDTO.class);

//         // Map DTO to entity
//         Employee employee = new Employee();
//         employee.setName(employeeDTO.getName());
//         employee.setEmail(employeeDTO.getEmail());
//         employee.setDepartment(employeeDTO.getDepartment());

//         // Handle document upload
//         if (document != null && !document.isEmpty()) {
//             byte[] documentBytes = document.getBytes();

//             String fileName = System.currentTimeMillis() + "_" + document.getOriginalFilename();
//             Path resourceDirectory = Paths.get("src", "main", "resources", "documents");
//             Files.createDirectories(resourceDirectory);
//             Path filePath = resourceDirectory.resolve(fileName);
//             Files.write(filePath, documentBytes);

//             employee.setDocuments(documentBytes);
//             employee.setDocumentPath(filePath.toString());
//         }

//         // Save employee
//         Employee savedEmployee = employeeService.createEmployee(employee);
//         return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
//     } catch (IOException e) {
//         logger.error("Error saving document", e);
//         return new ResponseEntity<>("Error processing request", HttpStatus.INTERNAL_SERVER_ERROR);
//     }
// }


    @PutMapping("/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails) {
        logger.info("PUT /employees/{} - Updating employee", id);
        return employeeService.updateEmployee(id, employeeDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        logger.info("DELETE /employees/{} - Deleting employee", id);
        employeeService.deleteEmployee(id);
    }
}
