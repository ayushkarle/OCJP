package com.bankappservice.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.bankappservice.Entity.AppUser;

import java.util.Optional;

public interface UserRepository extends JpaRepository<AppUser, Long> {
    Optional<AppUser> findByUsername(String username);
}
